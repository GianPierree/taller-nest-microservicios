export class CreateUserDto {
  name: string;
  email: string;
}
